<template>
  <div class="content">
    <router-view/>
  </div>
</template>

<style scoped>
  .content {
    margin-bottom: 4rem;
  }
</style>
