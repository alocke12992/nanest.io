import { Request, Response } from 'express'

export let get = (req: Request, res: Response) => { }

export let put = (req: Request, res: Response) => { }

export let deleteName = (req: Request, res: Response) => { }

export let post = (req: Request, res: Response) => { }