## created with [blix](https://blixjs.com/)

## Project Scripts

controller || example: blix generate controller <name> || use: Quickly create api/v1 get|post|put|delete endpoints for a resource


Create a file called `now-secrets.json` with your local db-url.

```
{
  "@db-url": "https://mypostrgresurl:5432",
  "@jwt-secret": "some_random_secret"
}
```